# -*- coding: utf-8 -*-

"""
sonoff_lan_mode_r3
"""

__author__ = """Andrew Beveridge"""
__email__ = 'andrew@beveridge.uk'
__version__ = '0.4.0'
__url__ = 'https://github.com/mattsaxon/sonoff_lan_mode'


